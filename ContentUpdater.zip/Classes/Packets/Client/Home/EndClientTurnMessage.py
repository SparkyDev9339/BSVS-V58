from Classes.Logic.LogicCommandManager import LogicCommandManager
from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Logic.LogicStarrDropData import starrDropOpening

from Database.DatabaseHandler import DatabaseHandler
import json

class EndClientTurnMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        self.readBoolean()
        fields["Tick"] = self.readVInt()
        fields["Checksum"] = self.readVInt()
        fields["CommandsCount"] = self.readVInt()
        super().decode(fields)
        fields["Commands"] = []
        for i in range(fields["CommandsCount"]):
            fields["Commands"].append({"ID": self.readVInt()})
            if LogicCommandManager.commandExist(fields["Commands"][i]["ID"]):
                command = LogicCommandManager.createCommand(fields["Commands"][i]["ID"])
                print("Command", LogicCommandManager.getCommandsName(fields["Commands"][i]["ID"]))
                if command is not None:
                    fields["Commands"][i]["Fields"] = command.decode(self)
                    fields["Commands"][i]["Instance"] = command
            else:
                print(fields["Commands"][i]["ID"], ': Unknown')
        return fields

    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        fields["PlayerID"] = calling_instance.player.ID
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        for command in fields["Commands"]:
            if "Instance" not in command.keys():
                return

            if hasattr(command["Instance"], 'execute'):
                command["Instance"].execute(calling_instance, command["Fields"])
            if command['ID'] == 571:
                for i in range(len(starrDropOpening.getStarrDropEncoding()) -1):
                        fields["Command"] = {"ID": 203}
                        player_data['BrawlPassSeason'] = 0
                        player_data['RewardForRank'] = 0
                        db_instance.updatePlayerData(player_data, calling_instance)
                        player_data['RewardForRank'] =  0
                        db_instance.updatePlayerData(player_data, calling_instance)

                        player_data["delivery_items"] = {
                        'Boxes': []
                        }
                        box = {
                        'Type': 0,
                        'Items': []
                        }
                        item = {'Amount': 1, 'DataRef': [0, 0], 'RewardID': 8}
                        box['Items'].append(item)
                        box['Type'] = 100
                        player_data["delivery_items"]['Boxes'].append(box)

                        db_instance.updatePlayerData(player_data, calling_instance)
                        Messaging.sendMessage(24111, fields, calling_instance.player)
                        starrDropOpening.refreshData()
                else:
                    player_data['BrawlPassSeason'] = 0
                    player_data['RewardForRank'] = 0
                    db_instance.updatePlayerData(player_data, calling_instance)
                    player_data['RewardForRank'] =  0
                    db_instance.updatePlayerData(player_data, calling_instance)

                    player_data["delivery_items"] = {
                    'Boxes': []
                    }
                    box = {
                    'Type': 0,
                    'Items': []
                    }
                    item = {'Amount': 1, 'DataRef': [0, 0], 'RewardID': 8}
                    box['Items'].append(item)
                    box['Type'] = 100
                    player_data["delivery_items"]['Boxes'].append(box)

                    db_instance.updatePlayerData(player_data, calling_instance)

                    fields["Command"] = {"ID": 203}
                    fields["reward"] = starrDropOpening.getStarrDropEncoding()[0]
                    Messaging.sendMessage(24111, fields, calling_instance.player)
                fields["Command"] = {"ID": 228}
                Messaging.sendMessage(24111, fields, calling_instance.player)

    def getMessageType(self):
        return 14102

    def getMessageVersion(self):
        return self.messageVersion